function toggleMode(){document.body.classList.toggle('dark');}
const b=document.createElement('button');b.textContent='Toggle Dark Mode';b.onclick=toggleMode;document.body.prepend(b);